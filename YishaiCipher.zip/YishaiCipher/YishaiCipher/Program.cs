﻿using System;
using System.Collections.Generic;

namespace YishaiCipher
{
    class Program
    {
        static void Main(string[] args)
        {
            //Choose to encrypt or decrypt
            string y;
            do
            {
                Console.WriteLine("To encrypt - type 1\nTo decrypt - type 2");
                y = Console.ReadLine();
                if (!(y.StartsWith('1') || y.StartsWith('2')))
                    Console.WriteLine("Not an option");
            } while (!(y.StartsWith('1') || y.StartsWith('2')));
            int x = Convert.ToInt32(y);

            //User types message and key
            
                Console.WriteLine("Type message with lowercase");
                string m = Console.ReadLine();

            do { if (m.Contains('A') ||
                     m.Contains('B') ||
                     m.Contains('C') ||
                     m.Contains('D') ||
                     m.Contains('E') ||
                     m.Contains('F') ||
                     m.Contains('G') ||
                     m.Contains('H') ||
                     m.Contains('I') ||
                     m.Contains('J') ||
                     m.Contains('K') ||
                     m.Contains('L') ||
                     m.Contains('M') ||
                     m.Contains('N') ||
                     m.Contains('O') ||
                     m.Contains('P') ||
                     m.Contains('Q') ||
                     m.Contains('R') ||
                     m.Contains('S') ||
                     m.Contains('T') ||
                     m.Contains('U') ||
                     m.Contains('V') ||
                     m.Contains('W') ||
                     m.Contains('X') ||
                     m.Contains('W') ||
                     m.Contains('Z'))
                { 
                    Console.WriteLine("Use lowercase only!");
                    Console.WriteLine("Type message");
                    m = Console.ReadLine();
                }
            } while (m.Contains('A') ||
                     m.Contains('B') ||
                     m.Contains('C') ||
                     m.Contains('D') ||
                     m.Contains('E') ||
                     m.Contains('F') ||
                     m.Contains('G') ||
                     m.Contains('H') ||
                     m.Contains('I') ||
                     m.Contains('J') ||
                     m.Contains('K') ||
                     m.Contains('L') ||
                     m.Contains('M') ||
                     m.Contains('N') ||
                     m.Contains('O') ||
                     m.Contains('P') ||
                     m.Contains('Q') ||
                     m.Contains('R') ||
                     m.Contains('S') ||
                     m.Contains('T') ||
                     m.Contains('U') ||
                     m.Contains('V') ||
                     m.Contains('W') ||
                     m.Contains('X') ||
                     m.Contains('W') ||
                     m.Contains('Z'));

                    Console.WriteLine("Type Keyword");
                    string k = Console.ReadLine();
            do
            {
                if (k.Contains('A') ||
                     k.Contains('B') ||
                     k.Contains('C') ||
                     k.Contains('D') ||
                     k.Contains('E') ||
                     k.Contains('F') ||
                     k.Contains('G') ||
                     k.Contains('H') ||
                     k.Contains('I') ||
                     k.Contains('J') ||
                     k.Contains('K') ||
                     k.Contains('L') ||
                     k.Contains('M') ||
                     k.Contains('N') ||
                     k.Contains('O') ||
                     k.Contains('P') ||
                     k.Contains('Q') ||
                     k.Contains('R') ||
                     k.Contains('S') ||
                     k.Contains('T') ||
                     k.Contains('U') ||
                     k.Contains('V') ||
                     k.Contains('W') ||
                     k.Contains('X') ||
                     k.Contains('W') ||
                     k.Contains('Z'))
                {
                    Console.WriteLine("Use lowercase only!");
                    Console.WriteLine("Type keyword");
                    k = Console.ReadLine();
                }
            } while (k.Contains('A') ||
                     k.Contains('B') ||
                     k.Contains('C') ||
                     k.Contains('D') ||
                     k.Contains('E') ||
                     k.Contains('F') ||
                     k.Contains('G') ||
                     k.Contains('H') ||
                     k.Contains('I') ||
                     k.Contains('J') ||
                     k.Contains('K') ||
                     k.Contains('L') ||
                     k.Contains('M') ||
                     k.Contains('N') ||
                     k.Contains('O') ||
                     k.Contains('P') ||
                     k.Contains('Q') ||
                     k.Contains('R') ||
                     k.Contains('S') ||
                     k.Contains('T') ||
                     k.Contains('U') ||
                     k.Contains('V') ||
                     k.Contains('W') ||
                     k.Contains('X') ||
                     k.Contains('W') ||
                     k.Contains('Z'));


            //turn message and key to listarray
            List<char> message = new List<char>();
            foreach (char letter in m)
            {
                message.Add(letter);
            }
            char[] key = k.ToCharArray();

            string letters = "abcdefghijklmnopqrstuvwxyz";
            List<char> alphabet = new List<char>();
            foreach (char letter in letters)
            {
                alphabet.Add(letter);
            }

            List<char> alpha = new List<char>();
            List<char> beta = new List<char>();
            char start = key[0];

            //key alphabet
            //make alpha alphabet
            for (int i = 0; i < 26; i++)
            {

                alpha.Add(start);

                if (start == 'z')
                    start = 'a';
                else
                    start = alphabet[alphabet.IndexOf(start) + 1];
            }

            //make beta alphabet
            start = key[1];

            for (int i = 0; i < 26; i++)
            {

                beta.Add(start);

                if (start == 'z')
                    start = 'a';
                else
                    start = alphabet[alphabet.IndexOf(start) + 1];
            }

            switch (x)
            {
                case 1:
                    //encrypt message
                    foreach (char letter in message)
                    {
                        //write letters
                        if (letter==' ')
                            Console.Write(" ");
                        else
                        Console.Write(alpha[beta.IndexOf(letter)]);

                        //move start back 3 letters
                        for (int i = 0; i < key.Length; i++)
                        {
                            if (start == beta[25])
                                start = beta[0];
                            else
                                start = beta[beta.IndexOf(start) + 1];
                        }
                        //reset beta and rewrite
                        beta.Clear();
                        for (int i = 0; i < 26; i++)
                        {
                            beta.Add(start);
                            
                            if (start == 'z')
                                start = 'a';
                            else
                                start = alphabet[alphabet.IndexOf(start) + 1];
                        }
                    }
                    break;
                case 2:
                    foreach (char letter in message)
                    {
                        //write letters
                        if (letter == ' ')
                            Console.Write(" ");
                        else
                        Console.Write(beta[alpha.IndexOf(letter)]);

                        //move start forward 3 letters
                        for (int i = 0; i < key.Length; i++)
                        {
                            if (start == beta[25])
                                start = beta[0];
                            else
                            start = beta[beta.IndexOf(start) + 1];
                        }
                        //reset beta and rewrite
                        beta.Clear();
                        for (int i = 0; i < 26; i++)
                        {
                            beta.Add(start);

                            if (start == 'z')
                                start = 'a';
                            else
                                start = alphabet[alphabet.IndexOf(start) + 1];
                        }
                    }
                    break;
            }
            Console.ReadKey();
        }

    }
}
