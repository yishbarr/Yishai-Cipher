﻿using System;
using System.Collections.Generic;

namespace YishaiCipher
{
    class Program
    {
        static void Main(string[] args)
        {
            //Choose to encrypt or decrypt
            string y;
            do
            {
                Console.WriteLine("To encrypt - type 1\nTo decrypt - type 2");
                y = Console.ReadLine();
                if (!(y.StartsWith('1') || y.StartsWith('2')))
                    Console.WriteLine("Not an option");
            } while (!(y.StartsWith('1') || y.StartsWith('2')));
            int x = Convert.ToInt32(y);

            //User types message and key
            
                Console.WriteLine("Type message with lowercase");
                string m = Console.ReadLine();

            string forbidden = "ABCDEFGHIJKLMNOPQRSTUVWXYZ1234567890-=!@#$%^&*()_+,./<>?";
            int checker=0;

            do {
                checker = 0;
                for (int i = 0; i < forbidden.Length; i++)
                {
    
                    if (m.Contains(forbidden[i]))
                    {
                        checker = 1;
                        Console.WriteLine("Use lowercase only!");
                        Console.WriteLine("Type message");
                        m = Console.ReadLine();
                    }
                }
                
            } while (checker==1);

                    Console.WriteLine("Type Keyword");
                    string k = Console.ReadLine();
            do
            {
                checker = 0;
                for (int i = 0; i < forbidden.Length; i++)
                {
                    
                    if (k.Contains(forbidden[i]))
                    {
                        checker = 1;
                        Console.WriteLine("Use lowercase only!");
                        Console.WriteLine("Type keyword");
                        k = Console.ReadLine();
                    }
                }
            } while (checker==1);


            //turn message and key to listarray
            List<char> message = new List<char>();
            foreach (char letter in m)
            {
                message.Add(letter);
            }
            char[] key = k.ToCharArray();

            string letters = "abcdefghijklmnopqrstuvwxyz";
            List<char> alphabet = new List<char>();
            foreach (char letter in letters)
            {
                alphabet.Add(letter);
            }

            List<char> alpha = new List<char>();
            List<char> beta = new List<char>();
            char start = key[0];

            //key alphabet
            //make alpha alphabet
            for (int i = 0; i < 26; i++)
            {

                alpha.Add(start);

                if (start == 'z')
                    start = 'a';
                else
                    start = alphabet[alphabet.IndexOf(start) + 1];
            }

            //make beta alphabet
            start = key[1];

            for (int i = 0; i < 26; i++)
            {

                beta.Add(start);

                if (start == 'z')
                    start = 'a';
                else
                    start = alphabet[alphabet.IndexOf(start) + 1];
            }

            switch (x)
            {
                case 1:
                    //encrypt message
                    foreach (char letter in message)
                    {
                        //write letters
                        if (letter==' ')
                            Console.Write(" ");
                        else
                        Console.Write(alpha[beta.IndexOf(letter)]);

                        //move start back 3 letters
                        for (int i = 0; i < key.Length; i++)
                        {
                            if (start == beta[25])
                                start = beta[0];
                            else
                                start = beta[beta.IndexOf(start) + 1];
                        }
                        //reset beta and rewrite
                        beta.Clear();
                        for (int i = 0; i < 26; i++)
                        {
                            beta.Add(start);
                            
                            if (start == 'z')
                                start = 'a';
                            else
                                start = alphabet[alphabet.IndexOf(start) + 1];
                        }
                    }
                    break;
                case 2:
                    foreach (char letter in message)
                    {
                        //write letters
                        if (letter == ' ')
                            Console.Write(" ");
                        else
                        Console.Write(beta[alpha.IndexOf(letter)]);

                        //move start forward 3 letters
                        for (int i = 0; i < key.Length; i++)
                        {
                            if (start == beta[25])
                                start = beta[0];
                            else
                            start = beta[beta.IndexOf(start) + 1];
                        }
                        //reset beta and rewrite
                        beta.Clear();
                        for (int i = 0; i < 26; i++)
                        {
                            beta.Add(start);

                            if (start == 'z')
                                start = 'a';
                            else
                                start = alphabet[alphabet.IndexOf(start) + 1];
                        }
                    }
                    break;
            }
            Console.ReadKey();
        }

    }
}
